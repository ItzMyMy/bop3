/* 
OPAL Shaders by FENVEN
https://www.youtube.com/@minecraftfenven567
based on
BSL Shaders by Capt Tatsu 
https://bitslablab.com 
*/ 

#version 120 

#define NETHER
#define VSH

#include "/program/dh_water.glsl"
