/* 
OPAL Shaders by FENVEN
https://www.youtube.com/@minecraftfenven567
based on
BSL Shaders by Capt Tatsu 
https://bitslablab.com 
*/ 

#version 120 

#extension GL_ARB_shader_texture_lod : enable

#define OVERWORLD
#define FSH

#include "/program/dh_water.glsl"
