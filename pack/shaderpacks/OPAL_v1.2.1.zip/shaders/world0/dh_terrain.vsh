/* 
OPAL Shaders by FENVEN
https://www.youtube.com/@minecraftfenven567
based on
BSL Shaders by Capt Tatsu 
https://bitslablab.com 
*/ 

#version 120 

#define OVERWORLD
#define VSH

#include "/program/dh_terrain.glsl"
