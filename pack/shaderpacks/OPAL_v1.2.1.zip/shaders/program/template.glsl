/* 
OPAL Shaders by FENVEN
https://www.youtube.com/@minecraftfenven567
based on
BSL Shaders by Capt Tatsu 
https://bitslablab.com 
*/ 

//Settings//
#include "/lib/settings.glsl"

//Fragment Shader///////////////////////////////////////////////////////////////////////////////////
#ifdef FSH

//Extensions//

//Varyings//

//Uniforms//

//Attributes//

//Optifine Constants//

//Common Variables//

//Common Functions//

//Includes//

//Program//
void main() {
    
}

#endif

//Vertex Shader/////////////////////////////////////////////////////////////////////////////////////
#ifdef VSH

//Varyings//

//Uniforms//

//Attributes//

//Optifine Constants//

//Common Variables//

//Common Functions//

//Includes//

//Program//
void main() {
    
}

#endif
