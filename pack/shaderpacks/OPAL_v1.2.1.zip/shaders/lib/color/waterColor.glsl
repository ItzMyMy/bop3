
#ifdef IS_IRIS
#ifndef OVERWORLD
vec4 waterColorSqrt = vec4(vec3(WATER_R, WATER_G, WATER_B) / 255.0, 1.0) * (WATER_I / 10.0);
vec4 waterColor = waterColorSqrt * waterColorSqrt;

const float waterAlpha = WATER_A;

const float waterFogRange = 64.0 / WATER_FOG_DENSITY;

#else
#if WATER_MODE == 0 || WATER_MODE == 2

vec4 waterColorSqrt = vec4(vec3(WATER_R, WATER_G, WATER_B) / 255.0, 1.0) * (WATER_I / 10.0);
vec4 waterColor = waterColorSqrt * waterColorSqrt;

const float waterAlpha = WATER_A;

const float waterFogRange = 64.0 / WATER_FOG_DENSITY;

#endif
#endif

#else

vec4 waterColorSqrt = vec4(vec3(WATER_R, WATER_G, WATER_B) / 255.0, 1.0) * (WATER_I / 10.0);
vec4 waterColor = waterColorSqrt * waterColorSqrt;

const float waterAlpha = WATER_A;

const float waterFogRange = 64.0 / WATER_FOG_DENSITY;

#endif