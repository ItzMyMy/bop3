#if defined END
vec3 blocklightColSqrt = vec3(BLOCKLIGHT_END_R, BLOCKLIGHT_END_G, BLOCKLIGHT_END_B) * BLOCKLIGHT_END_I / 255.0;
vec3 blocklightCol = blocklightColSqrt * blocklightColSqrt;
#elif defined NETHER
vec3 blocklightColSqrt = vec3(BLOCKLIGHT_NETHER_R, BLOCKLIGHT_NETHER_G, BLOCKLIGHT_NETHER_B) * BLOCKLIGHT_NETHER_I / 255.0;
vec3 blocklightCol = blocklightColSqrt * blocklightColSqrt;
#else
vec3 blocklightColSqrt = vec3(BLOCKLIGHT_R, BLOCKLIGHT_G, BLOCKLIGHT_B) * BLOCKLIGHT_I / 255.0;
vec3 blocklightCol = blocklightColSqrt * blocklightColSqrt;
#endif